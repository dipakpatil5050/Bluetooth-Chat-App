# Bluetooth Chat App using Flutter freamwork
created chat app with bluetooth API



https://user-images.githubusercontent.com/50947867/198204748-eb19b166-38a6-406b-bfd6-47e2e6e46d0c.mp4



https://user-images.githubusercontent.com/50947867/198204758-7812b52a-5b3f-4848-bda0-048b85044124.mp4

